# SEPIA STT-Server Docker Version

Use the scripts in this folder to install and run the Docker version of the SEPIA speech-recognition server.  
If you have issues with Docker or would like to use the "direct" installation check '../sepia-stt' folder.  
  
More info: https://github.com/SEPIA-Framework/sepia-stt-server/
