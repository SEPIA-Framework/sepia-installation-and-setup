#!/bin/bash
curl http://localhost:20741/ping
echo ""
