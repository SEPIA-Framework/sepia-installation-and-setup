#!/bin/bash
echo "Stopping SEPIA STT-Server Docker container ..."
sudo docker stop sepia-stt
