#!/bin/bash
sudo docker stop sepia-stt
