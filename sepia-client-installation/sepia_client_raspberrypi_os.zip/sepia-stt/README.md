# SEPIA STT-Server Direct Installation

Use the scripts in this folder to install and run the "direct" version of the SEPIA speech-recognition server (no extra Docker container).  
If you're having trouble during the installation process try the Docker version from '../sepia-stt-docker' folder.  
  
More info: https://github.com/SEPIA-Framework/sepia-stt-server/
