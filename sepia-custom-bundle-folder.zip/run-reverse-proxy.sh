#!/bin/bash
cd sepia-reverse-proxy
./run.sh
