#!/bin/bash
cd sepia-reverse-proxy
# TODO: auto-test for SSL cert and choose proper start script
./run_no_ssl.sh
#./run.sh
