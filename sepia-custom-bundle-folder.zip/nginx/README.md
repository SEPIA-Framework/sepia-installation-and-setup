# nginx settings
Configuration files to use nginx as reverse proxy and web-server for SEPIA.
To use the files copy them over to your nginx 'sites-enabled' folder and adjust the variables inside ([my-...]).
