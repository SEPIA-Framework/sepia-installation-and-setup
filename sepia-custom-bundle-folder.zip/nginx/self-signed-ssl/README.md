# Folder for self-signed SSL certificates

Put your self-signed certificates here and use the corresponding Nginx setup script.