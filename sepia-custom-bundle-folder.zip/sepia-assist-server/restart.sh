#!/bin/bash
./shutdown.sh
sleep 3
./run.sh

