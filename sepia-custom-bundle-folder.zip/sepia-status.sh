#!/bin/bash
ps -ef |grep java.*sepia-.*
ps -ef |grep java.*elasticsearch.*
