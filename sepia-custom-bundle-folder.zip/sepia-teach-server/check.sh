#!/bin/bash
ps -ef |grep java.*sepia-teach.*
