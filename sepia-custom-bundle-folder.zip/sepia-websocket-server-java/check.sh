#!/bin/bash
ps -ef |grep java.*sepia-chat.*
