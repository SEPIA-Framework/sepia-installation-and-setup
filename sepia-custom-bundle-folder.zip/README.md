# SEPIA custom-bundle folder
This is the base folder for the SEPIA custom-bundle. It contains all the start and setup scripts and certain configurations to operate your SEPIA-Framework.
