# SEPIA folder
This is the base folder for SEPIA when you copy it to the Raspberry Pi. It contains all the start and setup scripts and certain configurations.
