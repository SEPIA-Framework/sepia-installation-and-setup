#!/bin/sh

DOMAIN=secure.example.com
TOKEN=123
